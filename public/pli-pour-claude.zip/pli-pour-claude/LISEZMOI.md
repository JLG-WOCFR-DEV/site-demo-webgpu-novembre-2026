# PLI — archive pour Claude

Lis dans cet ordre : `NOTE.md` (la réflexion publiée sur les tweets), puis `PLI-REVUE.md` (le brief technique). Ta mission est la section 5 de `PLI-REVUE.md`, rôle Claude. Pas la mission Codex.

Ce n’est pas un dépôt exécutable seul. L’hôte TanStack Start n’est pas dans l’archive.

## Carte

| Fichier | Rôle |
|---|---|
| `NOTE.md` | Lecture des tweets, telle que publiée sur `/note` |
| `PLI-REVUE.md` | Brief : contrat, pipeline, angles, missions |
| `src/pli/engine.ts` | WebGPU + repli canvas + scroll / focus |
| `src/pli/content.ts` | Copie, presets, layout |
| `src/pli/raster.ts` | Texte rasterisé |
| `src/routes/index.tsx` | Démo |
| `src/routes/note.tsx` | Page de la note et le lien de téléchargement |
| `src/routes/__root.tsx` | Document, Archivo |
| `src/styles.css` | Tokens |
| `src/webgpu.d.ts` | Types WebGPU minimaux |
| `public/plates/*.jpg` | 6 photos, ratios déclarés à la main |

Interdit : Three.js, MSDF, auth, changer la palette ou les photos.
